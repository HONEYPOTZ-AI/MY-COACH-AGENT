# Contributing to My Coach Agent

We welcome contributions from the community! Here's how you can help:

## How to Contribute

1. Fork the repository
2. Create a new branch (`git checkout -b feature-name`)
3. Make your changes
4. Commit your changes (`git commit -am 'Add new feature'`)
5. Push to the branch (`git push origin feature-name`)
6. Create a Pull Request

## Code of Conduct

Please be respectful and inclusive in all interactions. We follow the Contributor Covenant Code of Conduct.

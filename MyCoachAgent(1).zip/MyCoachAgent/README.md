# My Coach Agent

My Coach Agent is an AI-powered career coaching and skill development platform designed to help users achieve their professional goals through personalized learning paths, resume building, job matching, and mentorship.

## Features

- AI Career Coach
- Skill Development Engine
- Job Matching & Resume Builder
- Progress Tracker & Analytics
- Community & Mentorship
- Gamification & Motivation

## Tech Stack

- Frontend: React + TailwindCSS
- Backend: FastAPI + PostgreSQL
- AI Layer: OpenAI, Claude, LangChain
- Infra: Kubernetes + Terraform + GitHub Actions
